#ifndef _YoukLx_grammar_var_
#define _YoukLx_grammar_var_

// 数据类型大小常量
#define lx_var_size sizeof(var)

// 整数位限制喵
#define lx_var_int_long 0x2710      //限4位，进1万喵
#define lx_var_int 0x3B9ACa00       //限9位，进10亿喵
// 小数位限制喵
#define lx_var_float 0x2710           //限4位，进1万喵

// 小数位限制喵
#define lx_var_fchar 0x1            //限1位，进2喵

#include <stdarg.h>
#include <string.h> 
#include <stdlib.h>

//自定义类型var喵
typedef struct {
    unsigned char led:2;                    //1位,决定类型的存储 
    union{
        struct {
            // 数据字段定义
            unsigned char ms:2;             //1位,决定类型的正负喵   
            unsigned short lli:14;          //15位,决定整数高位喵    
            unsigned int li:32;             //32位,决定整数低位喵     
            unsigned char pt:2;             //1位,决定是否为小数喵
            unsigned int ld:30;            //7位,决定小数高位喵
        } lx_var;
        struct {
            char* lxcd;         // 指向动态分配的字符串内存
            unsigned int lx_cl; // 存储字符串的实际长度
        } lx_str;
    } lx; 
} var;

//根据y的类型自动调用对应函数进行赋值喵
#define ass(x, y) _Generic((y), \
    short int: ass_short, \
    int: ass_int, \
    long int: ass_long, \
    long long int: ass_longlong, \
    float: ass_float, \
    double: ass_double,\
    char: ass_char, \
    default: ass_char \
)(x, y)

var ass_short(var a,short int b)
{
    a.led = 0;
    if(b >= 1420065400)
    {
        printf("数据溢出喵\n");
        a.lx.lx_var.li = 0;
        return a;
    }
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        if(b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = b;
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        if(-b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = -b;
        }   
    }
    return a;
}

var ass_int(var a,int b)
{
    a.led = 0;
    if(b >= 1420065400)
    {
        printf("数据溢出喵\n");
        a.lx.lx_var.li = 0;
        return a;
    }
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        if(b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = b;
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        if(-b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = -b;
        }
    }
    return a;
}

var ass_long(var a,long int b)
{
    a.led = 0;
    if(b >= 1420065400)
    {
        printf("数据溢出喵\n");
        a.lx.lx_var.li = 0;
        return a;
    }
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        if(b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = b;
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        if(-b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = -b;
        }
    }
    return a;
}
var ass_longlong(var a,long long int b)
{
    a.led = 0;
    if(b >= 1420065400)
    {
        printf("数据溢出喵\n");
        a.lx.lx_var.li = 0;
        return a;
    }
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        if(b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = b;
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        if(-b > lx_var_int)
        {
            a.lx.lx_var.li = b % lx_var_int;
            if((b / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(b / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = -b;
        }
    }
    return a;
}

var ass_float(var a,float b)
{
    a.led = 0;
    int c,e,d;
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        c = b;
        if(c > lx_var_int)
        {
            a.lx.lx_var.li = c % lx_var_int;
            if((c / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(c / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = c;
        }
        b = ((double)1 + (b - (double)c)) * lx_var_float * lx_var_float;
        if(b <= 908.0)
        {
            c = b;
        }
        else
        {
            c = b + 1;
        }
        if(c != 0)
        {
            a.lx.lx_var.pt = 1;
            e = 0;
            for(int i = 0;i<=6;i++)
            {
                if(c % 10 != 0)
                {
                    e = i;
                    break;
                }
                c = c / 10;
            }
            while(c >= lx_var_float * 10)
            {
                c = c / 10;
            }
            while(c)
            {
                a.lx.lx_var.ld = (a.lx.lx_var.ld *10) + c % 10;
                c = c / 10;
            }
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        c = -b;
        if(c > lx_var_int)
        {
            a.lx.lx_var.li = c % lx_var_int;
            if((c / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(c / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = c;
        }
        b = ((double)1+(-b - c)) * lx_var_float * lx_var_float;
        if(b <= 908.0)
        {
            c = b + 1;
        }
        else
        {
            c = b;
        }
        if(c != 0)
        {
            a.lx.lx_var.pt = 1;
            e = 0;
            for(int i = 0;i<=6;i++)
            {
                if(c % 10 != 0)
                {
                    e = i;
                    break;
                }
                c = c / 10;
            }
            while(c >= lx_var_float * 10)
            {
                c = c / 10;
            }
            while(c)
            {
                a.lx.lx_var.ld = (a.lx.lx_var.ld *10) + c % 10;
                c = c / 10;
            }
        }
    }
    return a;
}

var ass_double(var a,double b)
{
    a.led = 0;
    if(b > 999999999)
    {
        printf("数据溢出喵\n");
        a.lx.lx_var.li = 0;
        return a;
    }
    long long int c,e,d;
    if(b > 0)
    {
        a.lx.lx_var.ms = 0;
        c = b;
        if(c > lx_var_int)
        {
            a.lx.lx_var.li = c % lx_var_int;
            printf("%d\n",a.lx.lx_var.li);
            if((c / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(c / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = c;
        }
        b = ((double)1 + (b - (double)c)) * lx_var_float * lx_var_float;
        if(b <= 908.0)
        {
            c = b;
        }
        else
        {
            c = b + 1;
        }
        if(c != 0)
        {
            a.lx.lx_var.pt = 1;
            e = 0;
            for(int i = 0;i<=6;i++)
            {
                if(c % 10 != 0)
                {
                    e = i;
                    break;
                }
                c = c / 10;
            }
            while(c >= lx_var_float * 10)
            {
                c = c / 10;
            }
            while(c)
            {
                a.lx.lx_var.ld = (a.lx.lx_var.ld *10) + c % 10;
                c = c / 10;
            }
        }
    }
    else
    {
        a.lx.lx_var.ms = 1;
        c = -b;
        if(c > lx_var_int)
        {
            a.lx.lx_var.li = c % lx_var_int;
            if((c / lx_var_int) >= lx_var_int_long)
            {
                a.lx.lx_var.lli = lx_var_int_long - 1;
                printf("数据溢出喵\n");
            }
            else
            {
                a.lx.lx_var.lli = (unsigned int)(c / lx_var_int);
            }
        }
        else
        {
            a.lx.lx_var.li = c;
        }
        b = ((double)1+(-b - c)) * lx_var_float * lx_var_float;
        if(b <= 908.0)
        {
            c = b + 1;
        }
        else
        {
            c = b;
        }
        if(c != 0)
        {
            a.lx.lx_var.pt = 1;
            e = 0;
            for(int i = 0;i<=6;i++)
            {
                if(c % 10 != 0)
                {
                    e = i;
                    break;
                }
                c = c / 10;
            }
            while(c >= lx_var_float * 10)
            {
                c = c / 10;
            }
            while(c)
            {
                a.lx.lx_var.ld = (a.lx.lx_var.ld *10) + c % 10;
                c = c / 10;
            }
        }
    }
    return a;
}

var ass_char(var a, char* b)
{
    a.led = 1;
    if (a.lx.lx_str.lxcd != NULL) {
        free(a.lx.lx_str.lxcd);
    }
    a.lx.lx_str.lx_cl = strlen(b);
    a.lx.lx_str.lxcd = (char*)malloc(a.lx.lx_str.lx_cl + 1);  // +1 用于存储空字符
    if (a.lx.lx_str.lxcd == NULL) {
        printf("内存分配失败喵\n");
        a.lx.lx_str.lx_cl = 0;
        return a;
    }
    strcpy(a.lx.lx_str.lxcd, b);
    return a;
}


#endif