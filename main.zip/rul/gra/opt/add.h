#ifndef _YoukLx_grammar_operat_
#define _YoukLx_grammar_operat_

var add(var a){
    printf("Result: %d\n", a);
    return a;
}

#endif