#ifndef _YoukLx_grammar_lao_
#define _YoukLx_grammar_lao_

#include <stdio.h>
#include <rul/gra/variable.h>

#define print(x) _Generic((x), \
    var: print_var, \
    default: print_char \
)(x)

void print_var(var a){
    if(a.led == 0)
    {
        if(a.lx.lx_var.ms == 1) printf("-");
        if(a.lx.lx_var.lli != 0) printf("%d", a.lx.lx_var.lli);
        if(a.lx.lx_var.li != 0) 
            {
                unsigned long long b = a.lx.lx_var.ld;
                int c = 0;
                while(b)
                {
                    c++;
                    b /= 10;
                }
                b = a.lx.lx_var.ld;
                if(c == 9)
                {
                    printf("%d", b / (lx_var_int / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10 / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b / (lx_var_int / 10 / 10 / 10 / 10 / 10 / 10 / 10 / 10 / 10) % 10);
                    printf("%d", b % 10);
                }
                else
                {
                    printf("%d", a.lx.lx_var.li);
                }
            }
        if(a.lx.lx_var.pt == 1)
        {
            int pt = 0;
            if(a.lx.lx_var.ld != 0) 
            {
                unsigned int b = a.lx.lx_var.ld / 10;
                while(b)
                {
                    if(pt == 0)
                    {
                        printf(".");
                        pt = 1;
                    } 
                    printf("%d", b % 10);
                    b /= 10;
                }
            }
        }
    }
    else
    {
        if(a.lx.lx_str.lxcd != NULL) {
            printf("%s", a.lx.lx_str.lxcd);
        } 
        else {
            printf("字符串为空喵");
        }
    }
}

void print_char(char* a)
{
    printf("%s",a);
}

#endif