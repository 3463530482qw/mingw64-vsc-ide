#ifndef _YoukLx_grammar_arr_
#define _YoukLx_grammar_arr_

%define 

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <stdlib.h>
#include <string.h>



#endif

