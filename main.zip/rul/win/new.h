#ifndef _YoukLx_window_
#define _YoukLx_window_

// 图形库，标准库引用喵
#include <glfw/glfw3.h>
#include <glfw/glfw3native.h>

#include <iostream>
#include <cstdlib>
#include <memory>
#include <any>
#include <cmath>
#include <vector>
#include <fstream>
#include <chrono>
#include <random> 

// 用于图片创建喵
#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#define GL_CLAMP_TO_EDGE 0x812F
#include <stb_master/stb_image.h>
#include "stb_master/stb_truetype.h"

// 自定义库引用喵
#include <rul/win/icon.h>
#include <rul/win/adjust.h>
#include <rul/win/draw/image.h>
#include <rul/win/draw/load.h>

// 自定义删除器用于智能指针
struct GLFWwindowDeleter {
    void operator()(GLFWwindow* window) {
        if (window) {
            glfwDestroyWindow(window);
        }
    }
};

// 使用智能指针管理GLFWwindow
using GLFWwindowPtr = std::unique_ptr<GLFWwindow, GLFWwindowDeleter>;

GLFWwindowPtr lxw_new(GLFWwindow* shared = nullptr);    // 创建窗口喵
GLFWwindow* lxw_run(GLFWwindow* win);                   // 运行窗口喵
GLFWwindow* lxw_lcenter(GLFWwindow* win);               // 设置窗口位置居中喵
double lxw_gtime();                                     // 获取时间喵
float lxw_rand(int min = 0, int max = 1);               // 获取随机数喵

GLFWwindowPtr lxw_new(GLFWwindow* shared) {
    // 初始化GLFW图形库喵
    glfwInit();

    // 获取主窗显示器喵
    GLFWmonitor* monitor = glfwGetPrimaryMonitor();

    // 获取窗口模式喵
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);

    // 设置窗口大小喵
    int a = static_cast<int>((mode->width) * 0.8);
    int b = static_cast<int>((mode->height) * 0.8);
    int c,d;
    c = a / 16;
    d = b / 9;
    if (c < d){
        a = c * 16;
        b = c * 9;
    }
    else{
        a = d * 16;
        b = d * 9;
    }
    // 生成窗口喵
    GLFWwindow* raw_win = glfwCreateWindow(a, b, "窗口喵", nullptr, shared);
    
    GLFWwindowPtr win(raw_win); // 使用智能指针包装

    lxw_lcenter(win.get());

    // 设置窗口图标喵
    GLFWimage icon[1];
    icon[0].pixels = stbi_load(".vscode/icon.png", &icon[0].width, &icon[0].height, 0, 4); 
    if (icon[0].pixels) {
        glfwSetWindowIcon(win.get(), 1, icon);
    } else {
        printf("无法加载图标喵\n");
    }
    stbi_image_free(icon[0].pixels);

    printf("创建窗口大小: %d x %d喵\n", a, b);

    // 将窗口的上下文设置为当前线程的主上下文
    // 所有OpenGL的渲染操作都会在这个窗口上进行
    glfwMakeContextCurrent(win.get());


    return win;
}

//窗口待机喵
GLFWwindow* lxw_run(GLFWwindow* win) {
    glfwMakeContextCurrent(nullptr);
    glfwMakeContextCurrent(win);
    
    // 处理所有待处理的事件
    glfwPollEvents();
        
    // 交换前后缓冲区，显示渲染内容
    glfwSwapBuffers(win);
    
    // 设置清屏颜色
    glClearColor(0, 0, 0, 1.0f);
        
    // 清除颜色缓冲区
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    return win;
}

//设置窗口位置居中
GLFWwindow* lxw_lcenter(GLFWwindow* win) {
    //获取窗口中心位置喵
    int screenWidth, screenHeight;
    glfwGetMonitorWorkarea(glfwGetPrimaryMonitor(), nullptr, nullptr, &screenWidth, &screenHeight);
    
    // 计算窗口位置（考虑窗口大小）
    int windowWidth, windowHeight;
    glfwGetWindowSize(win, &windowWidth, &windowHeight);
    int xPos = (screenWidth - windowWidth) / 2;
    int yPos = (screenHeight - windowHeight) / 2;
    
    //设置窗口位置喵
    glfwSetWindowPos(win, xPos, yPos);
    return win;
}

double lxw_gtime()
{
    // 静态变量，只会在第一次调用时初始化
    static const auto start_time = std::chrono::high_resolution_clock::now();
    
    // 获取当前时间
    auto current_time = std::chrono::high_resolution_clock::now();
    
    // 计算时间差
    auto duration = std::chrono::duration_cast<std::chrono::duration<double>>(current_time - start_time);
    
    return duration.count();
}

float lxw_rand(int min, int max)
{ 
    static std::random_device rd;
    // 结合多个随机源来初始化种子
    static std::mt19937 gen(
        rd() ^                                            // 硬件随机数
        (static_cast<uint64_t>(lxw_gtime() * 1e9) << 32) ^ // 使用你的时间函数
        (reinterpret_cast<uintptr_t>(&gen))                // 地址空间随机化
    );
    
    // 创建整数分布，范围在[min*10, max*10]
    std::uniform_int_distribution<int> dis((min << 1) + (min << 3), (max << 1) + (max << 3));
    
    // 生成随机整数并转换为一位小数的浮点数
        return static_cast<float>(dis(gen)) * 0.1f;
}

#endif