#ifndef _YoukLx_window_
#define _YoukLx_window_


//图形库，标准库引用喵
#include <glfw/glfw3.h>
#include <glfw/glfw3native.h>
#include <stdio.h>
#include <stdlib.h>

//自定义库引用喵
#include <rul/gra/input_and_output.h>
#include <rul/gra/variable.h>
#include <rul/gra/opt/add.h>

//用于图片创建喵
#define STB_IMAGE_IMPLEMENTATION
#include <stb_master/stb_image.h>



GLFWwindow* lxw_new() {

    // 初始化GLFW图形库喵
    glfwInit();

    // 获取主窗显示器喵
    GLFWmonitor* monitor = glfwGetPrimaryMonitor();

    // 获取窗口模式喵
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);

    // 设置窗口大小喵
    int a,b;
    a = mode->width;
    b = mode->height;
    a = a * 0.8;
    b = b * 0.8;
    // 生成窗口喵
    GLFWwindow* win = glfwCreateWindow(a, b, "窗口喵", NULL, NULL);

    GLFWwindow* lxw_lcenter();
    lxw_lcenter(win);

    printf("创建窗口大小: %d x %d喵\n", a, b);

    // 将窗口的上下文设置为当前线程的主上下文
    // 所有OpenGL的渲染操作都会在这个窗口上进行
    glfwMakeContextCurrent(win);

    return win;
}


//窗口待机喵
void lxw_run(GLFWwindow* win) 
{
    // 处理所有待处理的事件
        glfwPollEvents();
        
        // 设置清屏颜色（深蓝色）
        glClearColor(0, 0, 0, 1.0f);
        
        // 清除颜色缓冲区
        glClear(GL_COLOR_BUFFER_BIT);
        
        // 交换前后缓冲区，显示渲染内容
        glfwSwapBuffers(win);
}

//设置窗口位置居中
GLFWwindow* lxw_lcenter(GLFWwindow* win)
{
    //获取窗口中心位置喵
    int screenWidth, screenHeight;
    glfwGetMonitorWorkarea(glfwGetPrimaryMonitor(), NULL, NULL, &screenWidth, &screenHeight);
    
    // 计算窗口位置（考虑窗口大小）
    int windowWidth, windowHeight;
    glfwGetWindowSize(win, &windowWidth, &windowHeight);
    int xPos = (screenWidth - windowWidth) / 2;
    int yPos = (screenHeight - windowHeight) / 2;
    
    //设置窗口位置喵
    glfwSetWindowPos(win, xPos, yPos);
    return win;
}

#endif