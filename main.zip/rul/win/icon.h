#ifndef _YoukLx_window_icon
#define _YoukLx_window_icon

GLFWwindow* lxw_icon(GLFWwindow* win, const char* path)
{
    GLFWimage icon[1];
    icon[0].pixels = stbi_load(path, &icon[0].width, &icon[0].height, 0, 4); 
    if (icon[0].pixels) {
        glfwSetWindowIcon(win, 1, icon);
        printf("图标已经替换喵\n");
    } else {
        printf("无法加载图标喵\n");
    }
    stbi_image_free(icon[0].pixels);
    return win;
}

#endif
