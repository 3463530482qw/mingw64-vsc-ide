#ifndef _YoukLx_window_adjust
#define _YoukLx_window_dajust

//固定窗口喵
GLFWwindow* lxw_fixe(GLFWwindow* win)
{
    int w, h;
    glfwGetWindowSize(win, &w, &h);
    glfwSetWindowSizeLimits(win, w, h, w, h);
    printf("窗口已经固定喵\n");
    return win;
}

//修改窗口大小喵
GLFWwindow* lxw_size(GLFWwindow* win, int a, int b)
{

    glfwSetWindowSize(win, a, b);
    int c,d;
    glfwGetWindowSize(win, &c, &d);
    if((a != c) && (b != d))
    {
        GLFWmonitor* monitor = glfwGetPrimaryMonitor();
        const GLFWvidmode* mode = glfwGetVideoMode(monitor);
        glfwSetWindowSizeLimits(win, 0, 0, mode->width, mode->height);
        glfwSetWindowSize(win, a, b);
        glfwSetWindowSizeLimits(win, a, b, a, b);
    }
    printf("窗口大小已调整为：%d x %d 喵\n", a, b);
}

#endif