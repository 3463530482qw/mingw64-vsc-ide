#ifndef _YoukLx_window_draw_
#define _YoukLx_window_draw_

GLuint lx_draw_imagei(const char* filename); // 加载图片喵
void lx_draw_image(GLuint a, float x = 0.0f, float y = 0.0f, float sizew = 1.0f, float sizeh = 1.0f,\
float rotate = 0.0f, float rw = 0.0f, float rh = 0.0f, float alpha = 1.0f); //绘制图片喵
void lx_draw_line(float x1 = 0.0f, float y1 = 0.0f, float x2 = 0.0f, float y2 = 0.0f, float lwid = 1.0f,\
float alpha = 1.0, float r = 255.0f , float g = 255.0f, float b = 255.0f);


GLuint lx_draw_imagei(const char* filename) {
    // 加载PNG图片
    int width, height, channels;
    unsigned char *image_data = stbi_load(filename, &width, &height, &channels, STBI_rgb_alpha);
    
    if (!image_data) {
        printf("无法加载图片\n");
        return -1;
    }
    
    // 创建OpenGL纹理
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    
    // 设置纹理参数
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    // 上传纹理数据到GPU
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_data);
    
    // 释放图片内存
    stbi_image_free(image_data);

    return texture;
}

void lx_draw_image(GLuint a, float x, float y,float sizew, float sizeh, float rotate, float rw, float rh, float alpha) {

    // 获取纹理大小
    GLint w, h;
    glBindTexture(GL_TEXTURE_2D, a);
    glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_WIDTH, &w);
    glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_HEIGHT, &h);

    // 获取窗口大小
    GLint b[4];
    glGetIntegerv(GL_VIEWPORT, b);

    //实际绘制大小
    float w1 = w * (2.0f / b[2]);
    float h1 = h * (2.0f / b[3]);
    x = x * (2.0f / b[2]);
    y = y * (2.0f / b[3]);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, a);
    
    // 设置纹理参数
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);

    float aspect_ratio = (float)b[2] / b[3];
    auto ucx = -1.0f + x;
    auto ucy = 1.0f - y;
    auto chx = ((0.0f + w1) * sizew) + x - 1.0f;
    auto chy = ((0.0f - h1) * sizeh) - y + 1.0f;
    auto orgx = ucx + (rw * (2.0f / b[2])) * aspect_ratio;
    auto orgy = ucy - (rh * (2.0f / b[3])) * aspect_ratio;
    float rxq1, ryq1, rxq2, ryq2, rxq3, ryq3, rxq4, ryq4;

    if (rotate != 0.0f) {
        rotate = rotate * (M_PI / 180.0f);
        auto rx = std::cos(rotate);
        auto ry = std::sin(rotate);
    
        float dx1 = (ucx - orgx) * aspect_ratio;
        float dy1 = ucy - orgy;
        rxq1 = (rx * dx1 - ry * dy1 - dx1) / aspect_ratio;
        ryq1 = ry * dx1 + rx * dy1 - dy1;
    
        float dx2 = (chx - orgx) * aspect_ratio;
        float dy2 = ucy - orgy;
        rxq2 = (rx * dx2 - ry * dy2 - dx2) / aspect_ratio;
        ryq2 = ry * dx2 + rx * dy2 - dy2;
    
        float dx3 = (chx - orgx) * aspect_ratio;
        float dy3 = chy - orgy;
        rxq3 = (rx * dx3 - ry * dy3 - dx3) / aspect_ratio;
        ryq3 = ry * dx3 + rx * dy3 - dy3;
    
        float dx4 = (ucx - orgx) * aspect_ratio;
        float dy4 = chy - orgy;
        rxq4 = (rx * dx4 - ry * dy4 - dx4) / aspect_ratio;
        ryq4 = ry * dx4 + rx * dy4 - dy4;
    } else {
        rxq1 = ryq1 = rxq2 = ryq2 = rxq3 = ryq3 = rxq4 = ryq4 = 0.0f;
    }

    glColor4f(1.0f, 1.0f, 1.0f, alpha);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(ucx + rxq1, ucy + ryq1);
    glTexCoord2f(1.0f, 0.0f); glVertex2f(chx + rxq2, ucy + ryq2);
    glTexCoord2f(1.0f, 1.0f); glVertex2f(chx + rxq3, chy + ryq3);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(ucx + rxq4, chy + ryq4);
    glEnd(); 

    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
}

void lx_draw_line(float x1, float y1, float x2, float y2, float lwid, float alpha, float r, float g, float b)
{
    r = r / 255.0f;
    g = g / 255.0f;
    b = b / 255.0f;
    
    // 获取窗口大小（与lx_draw_image相同的方法）
    GLint viewport[4];  // 改名为viewport避免与参数b冲突
    glGetIntegerv(GL_VIEWPORT, viewport);
    
    // 转换坐标（与lx_draw_image相同的转换方式）
    x1 = x1 * (2.0f / viewport[2]) - 1.0f;
    y1 = 1.0f - y1 * (2.0f / viewport[3]);
    x2 = x2 * (2.0f / viewport[2]) - 1.0f;
    y2 = 1.0f - y2 * (2.0f / viewport[3]);
    
    // 保存当前OpenGL状态
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    
    // 设置投影矩阵
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    // 设置渲染状态
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_TEXTURE_2D);  // 确保纹理被禁用
    
    // 设置线宽
    glLineWidth(lwid);

    // 设置线段端点样式
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glEnable(GL_LINE_SMOOTH);

    // 开始绘制线段
    glBegin(GL_LINES);
    glColor4f(r, g, b, alpha);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glEnd();
    
    // 恢复OpenGL状态
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
}

#endif