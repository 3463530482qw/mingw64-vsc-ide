#ifndef _YoukLx_window_load_
#define _YoukLx_window_load_

std::vector<GLuint> lx_load_image(const char* filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "加载失败喵" <<std::endl;
        return std::vector<GLuint>();  // 返回空数组表示加载失败
    }

    int count = 0,lcount = 0;
    std::string line;
    while (std::getline(file, line)) {
        count++;
    }

    file.clear();
    file.seekg(0, std::ios::beg);

    std::vector<GLuint> textures;
    
    while (std::getline(file, line)) {  // 修复：添加std::前缀
        GLuint texture_id = lx_draw_imagei(line.c_str());  // 修复：使用c_str()转换
        textures.push_back(texture_id);
        lcount++;
        float progress = (static_cast<float>(lcount) / count) * 100;
        std::cout << "图片已加载" << static_cast<int>(progress) << "%喵" << std::endl;
    }
    
    file.close();
    return textures;
}

#endif