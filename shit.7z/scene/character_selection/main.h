GLFWwindowPtr character_selection_main(GLFWwindowPtr win)
{
    auto c = lx_load_image("scene/character_selection/character_selection.txt");
    GLint sizew[4];
    glGetIntegerv(GL_VIEWPORT, sizew);
    float sizex = sizew[2] / 1600.0f;
    while(1)
    {
        lxw_run(win.get());
        lx_draw_image(c[0], 0, 0, 1, 1,0,0,0,1);
    }
}